﻿using System;
using System.Data;
using System.Text.RegularExpressions;
using Mono.Data.Sqlite;

namespace AgeRanger.Common
{
    public class PersonDAL
    {
        public string cs = string.Empty;
		private static PersonDAL instance;
        
        private PersonDAL(){}

		public static PersonDAL Instance
		{
			get
			{
				if (instance == null)
				{
					instance = new PersonDAL();
                    //cs = Common.Base.strDBConn;
				}
				return instance;
			}
		}

        /// <summary>
        /// Adds the person into database.
        /// </summary>
        /// <returns>The person.</returns>
        /// <param name="p">P.</param>
        public int AddPerson(Person p)
		{
			try
			{
                if (p.Age < 0 || !Common.Base.Validate(p.FirstName) || !Common.Base.Validate(p.LastName))
                    return -1;
                
				using (SqliteConnection con = new SqliteConnection(cs))
				{
					con.Open();

					SqliteCommand cmd4Count = new SqliteCommand("SELECT MAX(id) FROM Person", con);
                    object temObj = cmd4Count.ExecuteScalar();
                    int newID = (!temObj.Equals(DBNull.Value)) ? Convert.ToInt32(temObj) + 1 : 0;

                    SqliteCommand cmd4Insert = new SqliteCommand("INSERT INTO Person VALUES(" + newID + ",'" + p.FirstName + "','" + p.LastName + "'," + p.Age + ")", con);
					cmd4Insert.ExecuteNonQuery();

					con.Close();

                    return newID;
				}
			}
			catch (Exception ex)
			{
				throw new Exception("Add person failed: " + ex.Message);
			}
		}

		/// <summary>
		/// Searchs the person from database
		/// </summary>
		/// <returns>The person.</returns>
		/// <param name="c1">C1.</param>
		/// <param name="c2">C2.</param>
        public DataSet SearchPerson(string c1, string c2)
		{
			try
			{
				DataSet ds = new DataSet();

				using (SqliteConnection con = new SqliteConnection(cs))
				{
					con.Open();

					string query = @"SELECT * FROM 
                                    (SELECT t2.ID, t2.FirstName, t2.LastName,t2.Age, t1.Description 
                                    FROM agegroup t1, person t2 
                                    WHERE t2.age BETWEEN ifnull(t1.minage,t2.age) AND ifnull(t1.maxage,t2.age) ORDER BY Age) t3
                                    WHERE t3.FirstName LIKE '%" + c1 + "%'  AND t3.LastName LIKE '%" + c2 + "%'";


					var da = new SqliteDataAdapter(query, con);
					da.Fill(ds);


					con.Close();
				}

				return ds;
			}
			catch (Exception ex)
			{
				throw new Exception("Search user failed: " + ex.Message);
			}
		}

        /// <summary>
        /// Edits the person and update into database
        /// </summary>
        /// <param name="p">Person</param>
        public int EditPerson(Person p)
        {
            try
            {
				if (p.Age < 0 || !Common.Base.Validate(p.FirstName) || !Common.Base.Validate(p.LastName))
					return -1;
                
				using (SqliteConnection con = new SqliteConnection(cs))
				{
					con.Open();

					SqliteCommand cmd4Update = new SqliteCommand("UPDATE Person SET firstname = '" + p.FirstName + "', lastname = '" + p.LastName + "' , age = " + p.Age + " WHERE id=" + p.ID + "", con);
					cmd4Update.ExecuteNonQuery();

					con.Close();
				}

                return 1;
			}
            catch(Exception ex)
            {
                throw new Exception("Edit person failed: " + ex.Message);
            }
        }

        /// <summary>
        /// Deletes the person from database.
        /// </summary>
        /// <param name="id">Identifier.</param>
        public void DeletePerson(int id)
        {
            try
            {
				using (SqliteConnection con = new SqliteConnection(cs))
				{
					con.Open();

					SqliteCommand cmd4Delete = new SqliteCommand("DELETE FROM Person WHERE id=" + Convert.ToString(id), con);
					cmd4Delete.ExecuteNonQuery();

					con.Close();
				}
            }
            catch(Exception ex)
            {
                throw new Exception("Delete person failed: " + ex.Message);
            }
        }

        /// <summary>
        /// Deletes all persons from database.
        /// </summary>
		public void DeleteAll()
		{
			try
			{
				using (SqliteConnection con = new SqliteConnection(cs))
				{
					con.Open();

					SqliteCommand cmd4DeleteAll = new SqliteCommand("DELETE FROM Person", con);
					cmd4DeleteAll.ExecuteNonQuery();

					con.Close();
				}
			}
			catch (Exception ex)
			{
				throw new Exception("Delete all failed: " + ex.Message);
			}
		}

        /// <summary>
        /// Finds the person with user id from database.
        /// </summary>
        /// <returns>The person.</returns>
        /// <param name="id">Identifier.</param>
        public bool FindPerson(int id)
        {
            try
            {
				using (SqliteConnection con = new SqliteConnection(cs))
				{
					con.Open();

                    SqliteCommand cmd4Find = new SqliteCommand("SELECT count(*) FROM Person WHERE id=" + Convert.ToString(id), con);
                    int count = Convert.ToInt32(cmd4Find.ExecuteScalar());

					con.Close();

                    return count > 0 ? true : false;
				}
            }
            catch(Exception ex)
            {
                throw new Exception("Find person failed: " + ex.Message);
            }
        }

		/// <summary>
		/// Gets the person with user id from database.
		/// </summary>
		/// <returns>The person.</returns>
		/// <param name="id">Identifier.</param>
		public Person GetPerson(int id)
		{
            Person p = new Person();

			try
			{
				using (SqliteConnection con = new SqliteConnection(cs))
				{
					con.Open();

					SqliteCommand cmd4Select = new SqliteCommand("SELECT * FROM Person WHERE id=" + id + "", con);

					using (SqliteDataReader rdr = cmd4Select.ExecuteReader())
					{
						while (rdr.Read())
						{
                            p.FirstName = Convert.ToString(rdr["firstname"]);
                            p.LastName = Convert.ToString(rdr["lastname"]);
                            p.Age = Convert.ToInt32(rdr["age"]);
						}
					}

					con.Close();
				}

                return p;
			}
			catch (Exception ex)
			{
				throw new Exception("Find person failed: " + ex.Message);
			}
		}

        /// <summary>
        /// Loads the persons from database.
        /// </summary>
        /// <returns>The persons.</returns>
        public DataSet LoadPersons()
        {
            DataSet ds = new DataSet();

            try
            {
				using (SqliteConnection con = new SqliteConnection(cs))
				{
					con.Open();

					var da = new SqliteDataAdapter("SELECT t2.ID, t2.FirstName, t2.LastName,t2.Age, t1.Description FROM agegroup t1, person t2 WHERE t2.age BETWEEN ifnull(t1.minage,t2.age) AND ifnull(t1.maxage,t2.age) ORDER BY Age", con);
					da.Fill(ds);

					con.Close();

                    return ds;
				}
            }
            catch(Exception ex)
            {
                throw new Exception("Load persons failed: " + ex.Message);
            }
        }
    }
}
