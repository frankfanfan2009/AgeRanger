﻿using System;
using System.Text.RegularExpressions;
using System.Configuration;

namespace AgeRanger.Common
{
    static public class Base
    {
        public static string strDBConn = ConfigurationManager.AppSettings["dbConn"];
        public static string strDBConn4UnitTest = ConfigurationManager.AppSettings["dbConn4UnitTest"];

        public static string strWarningMsg4AddPersonFailed = "Add failed with wrong parameters!";

        // Request State Messages
        public static string SUCCESS = "success";
        public static string FAIL = "failed";

        /// <summary>
        /// Validate the specified name.
        /// </summary>
        /// <returns>The validate.</returns>
        /// <param name="name">Name.</param>
        public static bool Validate(string name)
        {
            if (Regex.IsMatch(name, @"^[a-zA-Z]+$"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


    }
}
