﻿using System;
using System.Data;
using System.Web;
using System.Web.UI;
using Mono.Data.Sqlite;
using AgeRanger.Common;

namespace AgeRanger
{
    public partial class Default : System.Web.UI.Page
    {
        private static string cs = Common.Base.strDBConn;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                PersonDAL.Instance.cs = cs;

                LoadPersons();

                //bool p = PersonDAL.Instance.FindPerson(2);
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                lblMsg.Text = ex.Message;
            }
        }

        public void buttonClickedAddPerson(object sender, EventArgs args)
        {
            lblMsg.Text = string.Empty;

            try
            {
                /*
                if(!(tbFN.Text != string.Empty && tbLN.Text != string.Empty && tbAge.Text != string.Empty))
                {
                    lblMsg.Text = Common.Base.strWarningMsg;
                    return;
                }*/

                // Call interface to add person into database
                int id = PersonDAL.Instance.AddPerson(new Person { FirstName = tbFN.Text, LastName = tbLN.Text, Age = Convert.ToInt32(tbAge.Text) });

                if(id == -1)
                {
                    lblMsg.Text = Common.Base.strWarningMsg4AddPersonFailed;
                }

				// Clear all inputs
				//  lblMsg.Text = "Added successfully!";
				tbFN.Text = string.Empty;
				tbLN.Text = string.Empty;
				tbAge.Text = string.Empty;

                LoadPersons();
            }
            catch(Exception ex)
            {
                string err = ex.Message;
                lblMsg.Text = ex.Message;
            }
        }

        public void buttonClickedSearch(object sender, EventArgs args)
        {
            lblMsg.Text = string.Empty;

            try
            {
				string c1 = tbSFN.Text != null ? tbSFN.Text : "";
				string c2 = tbSLN.Text != null ? tbSLN.Text : "";

                // Call interface to search users
                DataSet ds = PersonDAL.Instance.SearchPerson(c1,c2);

                // Bind data to GridView
				dataGrid.DataSource = ds.Tables[0].DefaultView;
				dataGrid.DataBind();
            }
            catch(Exception ex)
            {
                string err = ex.Message;
                lblMsg.Text = ex.Message;
            }
        }

        /// <summary>
        /// Loads the persons from database.
        /// </summary>
        private void LoadPersons()
        {
            try
            {
                // Call interface to load persons
                DataSet ds = PersonDAL.Instance.LoadPersons();

				// Bind data to GridView
				dataGrid.DataSource = ds.Tables[0].DefaultView;
				dataGrid.DataBind();
            }
            catch(Exception ex)
            {
				string err = ex.Message;
				lblMsg.Text = ex.Message;
            }
        }
    }
}
