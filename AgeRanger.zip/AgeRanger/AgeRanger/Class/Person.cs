﻿﻿using System;

namespace AgeRanger
{
    /// <summary>
    /// Define a Person class object
    /// </summary>
    public class Person
    {
        public Person(){}

        public int ID { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public int Age { get; set; }
    }
}
