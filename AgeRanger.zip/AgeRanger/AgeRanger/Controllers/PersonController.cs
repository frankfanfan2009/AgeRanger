﻿using System;
using System.Web;
using System.Web.Http;
using System.Collections.Generic;
using AgeRanger;
using Mono.Data.Sqlite;
using AgeRanger.Common;

namespace AgeRanger.Controllers
{
    public class PersonController : ApiController
    {
        private static string cs = Common.Base.strDBConn; 

        public PersonController(){}

        /*
        static List<string> strings = new List<string>(){
            "value1","value2","value3"
        };

        public IEnumerable<string> Get(){
            return strings;
        }*/

        // GET api/person/5
        public string Get(int id)
        {
            string result = string.Empty;

            Person p = PersonDAL.Instance.GetPerson(id);
            result = p.FirstName + " " + p.LastName + " " + p.Age;

			return result;
        }

        // POST api/person
        public string Post([FromBody]Person value)
        {
            try
            {
                int result = PersonDAL.Instance.EditPerson(value);

                return result > 0 ? Common.Base.SUCCESS : Common.Base.FAIL;

			}
            catch(Exception ex)
            {
                string err = ex.Message;

                return Common.Base.FAIL + err;
            }
        }

        // PUT api/person/5
        public void Put(int id, [FromBody]object value)
        {
            //strings[id] = value;
        }

        // DELETE api/person/5
        public string DELETE(int id)
        {
            string result = string.Empty;

            try
            {
                PersonDAL.Instance.DeletePerson(id);

                return Common.Base.SUCCESS;
            }
            catch(Exception ex)
            {
                result = ex.Message;
                return Common.Base.FAIL + result;
            }
        }
    }
}
