﻿#   AgeRanger:
**Created by Frank Fan, 06/21/2017**
  - Note: please replace the <dbConn4UnitTest> values in Web.Config file with your local absolute path 
of AgeRanger.db in current unit project before trying to run.

#   Instructions:
  - This web single page application provides four interfaces for end users to add, search, edit and delete person into or from local AgeRanger.db.

  - It also provide WebApi(Get, Post, Delete) to access AgeRanger.db.

#   Environment:
  - Visual Studio Community Version
  - ASP.NET 4.5
  - Mono.Data.Sqlite
  - Jquery 3.2.1-min.js

#   How to use:
  - Add - It can create a new person record into local database.

  - Search - It can retrieve all users as long as their name contains the characters you input.

  - Edit - It can edit the existing person in local database with updated information like FirstName, LastName or Age. User ID must be provided before editing, it links to the person you want to edit. 

  - Delete - It can delete this person from local database with User ID you specified.

  - Get - It can get specified person with the user id you provided.

#   WebAPI Demos:
Get a Person
```sh
http://127.0.0.1:8080/api/person/{id}
```
Edit a Person
```sh
       $.post("/api/person", {id: {id}, firstname: {fn}, lastname: {ln}, age: {age}}).done(function( data ) {
         // Do something with the result
       })
```
Delete a Person
```sh
        $.ajax({
            url: "api/person/" + {id},
            type: "DELETE",
            success: function(result) {
                // Do something with the result
            },
            dataType: "text"
        });
```
**Have fun! :)**