namespace AgeRanger {
	
	public partial class Default {
		
		protected System.Web.UI.HtmlControls.HtmlForm form1;
		protected System.Web.UI.WebControls.GridView dataGrid;

		protected System.Web.UI.WebControls.Label lblMsg;

		protected System.Web.UI.WebControls.Button btnAdd;
		protected System.Web.UI.WebControls.Button btnSearch;

        protected System.Web.UI.WebControls.TextBox tbFN;
        protected System.Web.UI.WebControls.TextBox tbLN;
        protected System.Web.UI.WebControls.TextBox tbAge;
        protected System.Web.UI.WebControls.TextBox tbSFN;
        protected System.Web.UI.WebControls.TextBox tbSLN;
        protected System.Web.UI.WebControls.TextBox tbEID;
		protected System.Web.UI.WebControls.TextBox tbEFN;
		protected System.Web.UI.WebControls.TextBox tbELN;
        protected System.Web.UI.WebControls.TextBox tbEAge;
        protected System.Web.UI.WebControls.TextBox tbDel;

	}
}
