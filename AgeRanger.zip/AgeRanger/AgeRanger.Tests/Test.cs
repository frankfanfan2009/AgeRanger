﻿using NUnit.Framework;
using AgeRanger.Common;
using System.Data;

namespace AgeRanger.Tests
{
    [TestFixture]
    public class Test
    {
        [Test]
        public void TestCase4AddPersonSuccess()
        {
            PersonDAL.Instance.cs = Common.Base.strDBConn4UnitTest;
            PersonDAL.Instance.DeleteAll();

            Person p = new Person { FirstName = "TestFN", LastName = "TestLN", Age = 55 };

            int id = PersonDAL.Instance.AddPerson(p);
            Person pResult = PersonDAL.Instance.GetPerson(id);

            Assert.AreEqual(pResult.FirstName, "TestFN");
            Assert.AreEqual(pResult.LastName, "TestLN");
            Assert.AreEqual(pResult.Age, 55);
        }

        [Test]
        public void TestCase4AddPersonFailed()
        {
            PersonDAL.Instance.cs = Common.Base.strDBConn4UnitTest;

			Person p1 = new Person { FirstName = "Test2FN", LastName = "Test2LN", Age = -1 };
			Person p2 = new Person { FirstName = "Test2FN", LastName = "TestLN", Age = 10 };
			Person p3 = new Person { FirstName = "TestFN", LastName = "Test2LN", Age = 10 };

            int id1 = PersonDAL.Instance.AddPerson(p1);
            Assert.AreEqual(id1, -1);

            int id2 = PersonDAL.Instance.AddPerson(p2);
            Assert.AreEqual(id2, -1);

            int id3 = PersonDAL.Instance.AddPerson(p3);
            Assert.AreEqual(id3, -1);
        }

        [Test]
        public void TestCase4SearchPersonSuccess()
        {
            PersonDAL.Instance.cs = Common.Base.strDBConn4UnitTest;
            PersonDAL.Instance.DeleteAll();

			Person p = new Person { FirstName = "TestFN", LastName = "TestLN", Age = 55 };
			PersonDAL.Instance.AddPerson(p);

            int count1 = PersonDAL.Instance.SearchPerson("estF", "stL").Tables[0].Rows.Count;
            Assert.AreEqual(count1, 1);

            int count2 = PersonDAL.Instance.SearchPerson(null, "stL").Tables[0].Rows.Count;
            Assert.AreEqual(count2, 1);

            int count3 = PersonDAL.Instance.SearchPerson("estF", null).Tables[0].Rows.Count;
            Assert.AreEqual(count3, 1);
        }

        [Test]
        public void TestCase4SearchPersonFailed()
        {
            PersonDAL.Instance.cs = Common.Base.strDBConn4UnitTest;

            int count1 = PersonDAL.Instance.SearchPerson("999", "999").Tables[0].Rows.Count;
            Assert.AreEqual(count1, 0);

            int count2 = PersonDAL.Instance.SearchPerson(null, "999").Tables[0].Rows.Count;
            Assert.AreEqual(count2, 0);

            int count3 = PersonDAL.Instance.SearchPerson("999", null).Tables[0].Rows.Count;
            Assert.AreEqual(count3, 0);
        }

		[Test]
		public void TestCase4EditPersonSuccess()
		{
			PersonDAL.Instance.cs = Common.Base.strDBConn4UnitTest;
            PersonDAL.Instance.DeleteAll();

			Person p = new Person { FirstName = "NewPersonFN", LastName = "NewPersonLN", Age = 55 };
			int newId = PersonDAL.Instance.AddPerson(p);

            p.FirstName = "UpdatedPersonFN";
            p.LastName = "UpdatedPersonLN";
            p.Age = 56;

            PersonDAL.Instance.EditPerson(p);

            Person pResult = PersonDAL.Instance.GetPerson(newId);
            Assert.AreEqual(pResult.FirstName, "UpdatedPersonFN");
            Assert.AreEqual(pResult.LastName, "UpdatedPersonLN");
            Assert.AreEqual(pResult.Age, 56);
		}

        [Test]
        public void TestCase4EditPersonFailed()
        {
            PersonDAL.Instance.cs = Common.Base.strDBConn4UnitTest;
            PersonDAL.Instance.DeleteAll();

			Person p = new Person { FirstName = "NewPersonFN", LastName = "NewPersonLN", Age = 55 };
			int newId = PersonDAL.Instance.AddPerson(p);

			p.FirstName = "UpdatedPersonFN11";
			p.LastName = "UpdatedPersonLN11";
			p.Age = -1;

			PersonDAL.Instance.EditPerson(p);

			Person pResult = PersonDAL.Instance.GetPerson(newId);
			Assert.AreEqual(pResult.FirstName, "NewPersonFN");
			Assert.AreEqual(pResult.LastName, "NewPersonLN");
			Assert.AreEqual(pResult.Age, 55);
        }
    }
}
